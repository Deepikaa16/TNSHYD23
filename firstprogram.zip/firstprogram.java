
public class firstprogram {

	public static void main(String[] args) {
		System.out.println("hello world");
		// TODO Auto-generated method stub

	}

}
